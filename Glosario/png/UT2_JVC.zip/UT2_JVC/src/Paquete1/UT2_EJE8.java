package Paquete1;

import java.util.Scanner;

public class UT2_EJE8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		float x,y;
		System.out.println("Escibre los numeros con lo que quieres operar ");
		System.out.println("Introduce el valor de X ");
		x= teclado.nextInt();
		System.out.println("Introduce el valor de Y ");
		y= teclado.nextInt();
		
		System.out.println("X + Y es = "+(x+y));
		System.out.println("X - Y es = "+(x-y));
		System.out.println("X * Y es = "+(x*y));
		System.out.println("X / Y es = "+(x/y));
		System.out.println("X elevado a 2 es = "+(Math.pow(x, 2)));
		System.out.println("La raiz cuadrada de X es= "+(Math.sqrt(x)));
		
		
	}
	

}
