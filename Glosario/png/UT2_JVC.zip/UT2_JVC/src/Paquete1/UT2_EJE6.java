package Paquete1;
/**
 * 
 * @author dam
 * @class UT2_EJE6
 * @descripcion
 */

public class UT2_EJE6 {
	public enum Meses{Enero, Febrero, Marzo, Abril, Mayo, Junio, Julio, Agosto, Septiembre, Noviembre, Diciembre};
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		Meses Mesactual= Meses.Marzo;
		
		System.out.println("Estamos en el mes de "+ Mesactual);
		

	}

}
