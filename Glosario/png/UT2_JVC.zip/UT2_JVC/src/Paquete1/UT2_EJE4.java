package Paquete1;
/**
 * 
 * @author dam
 * @class UT2_EJE4
 * @description
 */
public class UT2_EJE4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Inicializo variables
		boolean casado= true;
		int max= 999999;
		byte diasemana= 1;
		int diaño=300;
		char sexo='M';
		long miliseg=12983328000000L;
		double totalfactura=10350.678;
		long poblacion=6775235741L;
		
		//println
		System.out.println("El valor de la variable casado es: "+casado);
		System.out.println("\tEl valor de la variable MAXIMO es: "+max);
		System.out.println("\tEL valor de la variable diasem es: "+diasemana);
		System.out.println("\tEL valor de la variable diaaanual es: "+diaño);
		System.out.println("\tEL valor de la variable miliseg es: "+miliseg);
		System.out.println("\tEL valor de la variable totalfactura es: "+totalfactura);
		System.out.println("\tEL valor de la variable poblacion es: "+poblacion);
		System.out.println("\tEL valor de la variable sexo es: "+'M');
		
		//printf
		System.out.printf("El valor de la variable casado es %b\n", casado);
		System.out.printf("\tEl valor de la variable MAXIMO es %d\n", max);
		System.out.printf("\tEl valor de la variable diasem es %d\n", diasemana);
		System.out.printf("\tEl valor de la variable diaanual es %d\n", diaño);
		System.out.printf("\tEl valor de la variable diamiliseg es %d\n", miliseg);
		System.out.printf("\tEl valor de la variable poblacion es %d\n", poblacion);
		System.out.printf("\tEl valor de la variable sexo es %c\n", sexo);
		System.out.printf("\tEl valor de la variable totalfactura es %.6f\n", totalfactura);
		System.out.printf("\tEl valor de la variable totalfactura es %.6E\n", totalfactura);
	}//main

}//UT2_EJE4

