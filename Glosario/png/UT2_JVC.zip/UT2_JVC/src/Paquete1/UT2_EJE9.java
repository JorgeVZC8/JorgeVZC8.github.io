package Paquete1;

import java.util.Scanner;

public class UT2_EJE9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado= new Scanner(System.in);
		String x;
		
		System.out.println("Introduzca la cifra que quiera descomponer");
		System.out.println("Introduce un numero de 5 digitos");
		x= teclado.nextLine();
		
		System.out.println(x.substring(0,1)+" "+x.substring(1,2)+" "+x.substring(2,3)+" "+x.substring(3,4)+" "+x.substring(4));

	}

}
