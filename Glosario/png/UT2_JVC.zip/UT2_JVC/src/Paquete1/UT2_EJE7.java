package Paquete1;

import java.util.Scanner;

public class UT2_EJE7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	
		Scanner teclado = new Scanner(System.in);
		float C1,C2;
		
		System.out.println("Resolucion ecuacion de primer grado C1x +C2 =0 ");
		System.out.println("Introduce C1 ");
		C1= teclado.nextInt();
		System.out.println("Introduce C2 ");
		C2= teclado.nextInt();
	
		float x=-C1/C2;
		System.out.println("X vale "+x);
		
	}

}

