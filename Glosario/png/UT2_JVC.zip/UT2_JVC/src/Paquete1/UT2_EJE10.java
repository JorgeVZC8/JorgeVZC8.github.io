package Paquete1;

import java.util.Scanner;

public class UT2_EJE10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado= new Scanner(System.in);
		double L1,L2,L3;
		
		System.out.println("Para calcular el area del triangulo:");
		System.out.println("Introduce L1: ");
		L1= teclado.nextInt();
		System.out.println("Introduce L2: ");
		L2= teclado.nextInt();
		System.out.println("Introduce L3: ");
		L3= teclado.nextInt();
		
		double SP=(L1+L2+L3)/2;
		double area= Math.sqrt(SP*(SP-L1)*(SP-L2)*(SP-L3));
		
		System.out.println("El area del triangulo definido es "+area);
}
}
