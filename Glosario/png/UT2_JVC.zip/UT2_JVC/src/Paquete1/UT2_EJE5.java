package Paquete1;
import java.util.Scanner;


public class UT2_EJE5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		int x,y;
		System.out.println("introducir un numero ");
		x= teclado.nextInt();
		System.out.println("introduce un numero ");
		y= teclado.nextInt();
		
		String texto=((x%y)==0)?"es múliplo":"no es multiplo";
		
		System.out.println(y+" "+texto+ " de "+x);


}
	
}